let Todos = [
        {
            id: "1",
            title: "Something to do",
            done: true,
        },
        {
            id: "2",
            title: "Another thing to do",
            done: false,
        },
        {
            id: "3",
            title: "Boring task",
            done: true,
        },
    ]


module.exports = {Todos};