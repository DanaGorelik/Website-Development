# Welcome to your Wix Enter exam

## Prerequisites:
NPM (version 8 or 9)
Node (version 18)

## Instructions
- open a terminal and navigate to this project's dir
- run `npm install`
- run `npm start`
- run `npm test` to run the tests (the example tests should all pass)

## Requirements:
### Change todo status:

1. Clicking on the `Done` or `Todo` buttons of a TodoItem should change its status accordingly
