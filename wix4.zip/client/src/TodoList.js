// TodoList.js
import React, { useState } from "react";
import axios from "axios";
import "./TodoList.css";
import {
  Button,
  Container,
  Grid,
  List,
  ListItem,
  ListItemText,
  TextField,
  Typography,
  ToggleButtonGroup,
  ToggleButton,
  Divider,
} from "@mui/material";

const TodoList = ({ todos, addTodo, baseURL }) => {
  axios.defaults.withCredentials = true;

  const [newTitle, setNewTitle] = useState([]);

  const handleChangeStatus = async (id) => {
    try {
      const response = await axios.put(`${baseURL}/todos/${id}`, {}, {
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
      });
  
      if (response && response.data && response.data.status === 200) {
        // Update the state or perform any other necessary actions
        console.log(response)
      } else {
        console.log("Invalid response or status");
      }
    } catch (error) {
      console.log(error);
    }
  };
  
  return (
    <Container maxWidth="sm">
      <br />
      <Typography
        variant="h4"
        align="center"
        gutterBottom
        data-testid="todoListing-title"
      >
        TODO list
      </Typography>
      {todos.length === 0 ? (
        <Typography
          variant="body1"
          align="center"
          data-testid="todoListing-notodosAvailable"
        >
          No todos available.
        </Typography>
      ) : (
        <List data-testid={"todoListing-list"}>
          {todos.map((todo) => (
            <ListItem
              key={todo.id}
              disablePadding
              className={todo.done ? "done" : "todo"}
            >
              <ListItemText
                primary={todo.title}
                secondary={todo.author}
                data-testid={`todoListing-todo-${todo.id}`}
              />
              <ToggleButtonGroup
                color="primary"
                value={todo.done ? "done" : "todo"}
                exclusive
                onClick={()=>handleChangeStatus(todo)}
              >
                <ToggleButton value="done">Done</ToggleButton>
                <ToggleButton value="todo">Todo</ToggleButton>
              </ToggleButtonGroup>
            </ListItem>
          ))}
        </List>
      )}
      <Grid item xs={12}>
        <Typography variant="h6" data-testid={`todoList-addTodo-title`}>
          Add todo
        </Typography>
        <TextField
          label="Title"
          fullWidth
          margin="normal"
          onChange={(event) => {
            setNewTitle(event.target.value);
          }}
          data-testid={`todoList-addTodo-title`}
        />
        <Button
          variant="contained"
          color="primary"
          onClick={(e) => addTodo(newTitle)}
          data-testid={`todoList-addTodo-submitBtn`}
        >
          Submit TODO
        </Button>
      </Grid>
    </Container>
  );
};

export default TodoList;
